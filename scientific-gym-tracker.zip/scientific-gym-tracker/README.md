# Scientific Gym Tracker — Protótipo de Experiência do Cliente

Protótipo navegável (Next.js + Tailwind) com as 5 telas principais do app, para análise/validação de UX. Build já testado e funcionando (`npm run build`).

Telas incluídas:
1. Onboarding (dados básicos + nível)
2. Dashboard (resumo do dia)
3. Treino ao vivo (Workout Player)
4. Confirmação de bioimpedância (OCR)
5. Progresso corporal

## Rodar localmente

```bash
npm install
npm run dev
```

Abra `http://localhost:3000`.

## Subir para o GitHub

```bash
cd scientific-gym-tracker
git init
git add .
git commit -m "Protótipo inicial - experiência do cliente"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/scientific-gym-tracker.git
git push -u origin main
```

Se ainda não criou o repositório: vá em [github.com/new](https://github.com/new), crie um repositório vazio (sem README/gitignore, pra não conflitar), copie a URL e use no `git remote add origin`.

## Deploy na Vercel

**Opção A — pelo site (mais simples):**
1. Acesse [vercel.com/new](https://vercel.com/new)
2. Conecte sua conta GitHub e selecione o repositório `scientific-gym-tracker`
3. A Vercel detecta Next.js automaticamente — não precisa mudar nenhuma configuração
4. Clique em "Deploy"

**Opção B — pela CLI:**
```bash
npm install -g vercel
vercel login
vercel
```
Siga o passo a passo no terminal (ele detecta o framework sozinho). Depois, para produção:
```bash
vercel --prod
```

## Próximos passos sugeridos
- Conectar dados reais (hoje os campos são estáticos/mockados)
- Trocar os ícones emoji pela biblioteca de ícones definitiva
- Adicionar as telas de "máquina ocupada" e "foto de refeição" quando quiser expandir
