"use client";

import { useState } from "react";

export default function Onboarding() {
  const [level, setLevel] = useState("iniciante");

  return (
    <div className="p-4">
      <p className="text-xs text-slate-500 mb-1">Passo 2 de 6</p>
      <h3 className="text-lg font-medium mb-1">Sobre você</h3>
      <p className="text-sm text-slate-400 mb-4">Leva menos de 1 minuto.</p>

      <label className="text-xs text-slate-400">Idade</label>
      <input type="number" placeholder="38" className="w-full mt-1 mb-3" />

      <label className="text-xs text-slate-400">Altura (cm)</label>
      <input type="number" placeholder="173" className="w-full mt-1 mb-3" />

      <label className="text-xs text-slate-400">Peso (kg)</label>
      <input type="number" placeholder="64" className="w-full mt-1 mb-4" />

      <p className="text-xs text-slate-400 mb-2">Nível de experiência</p>
      <div className="flex gap-2 mb-5">
        {["iniciante", "intermediario", "avancado"].map((opt) => (
          <button
            key={opt}
            onClick={() => setLevel(opt)}
            className={`flex-1 text-xs py-2 rounded-lg border capitalize ${
              level === opt
                ? "bg-emerald-500/10 border-emerald-500 text-emerald-400"
                : "border-slate-800 text-slate-400"
            }`}
          >
            {opt === "intermediario" ? "Intermed." : opt === "avancado" ? "Avançado" : "Iniciante"}
          </button>
        ))}
      </div>

      <button className="w-full bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-medium py-2.5 rounded-lg">
        Continuar
      </button>
    </div>
  );
}
