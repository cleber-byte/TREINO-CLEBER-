const fields = [
  { label: "Peso", value: "64,0 kg" },
  { label: "PGC", value: "28,9%" },
  { label: "Massa muscular", value: "24,9 kg" },
  { label: "Gordura visceral", value: "nível 7" },
];

export default function Bioimpedance() {
  return (
    <div className="p-4">
      <h3 className="text-lg font-medium mb-0.5">Confirme os dados</h3>
      <p className="text-xs text-slate-400 mb-3">Extraídos do laudo enviado</p>

      <div className="bg-slate-900 border border-slate-800 rounded-xl h-24 flex items-center justify-center mb-3">
        <span className="text-3xl">📋</span>
      </div>

      <div className="text-sm">
        {fields.map((f) => (
          <div
            key={f.label}
            className="flex justify-between py-1.5 border-b border-slate-800 last:border-0"
          >
            <span className="text-slate-400">{f.label}</span>
            <span>{f.value}</span>
          </div>
        ))}
      </div>

      <p className="text-[11px] text-slate-500 my-3">
        Algo errado? Toque no valor para corrigir antes de salvar.
      </p>

      <button className="w-full bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-medium py-2.5 rounded-lg">
        Confirmar e salvar
      </button>
    </div>
  );
}
