const metrics = [
  { label: "Peso", value: "66,2 → 64,0" },
  { label: "PGC", value: "30,2 → 28,9" },
  { label: "Músculo", value: "25,3 → 24,9" },
];

export default function Progress() {
  return (
    <div className="p-4">
      <h3 className="text-lg font-medium mb-0.5">Seu progresso</h3>
      <p className="text-xs text-slate-400 mb-3">08/05 → 12/08</p>

      <div className="flex gap-2 mb-3">
        <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl h-36 flex items-center justify-center">
          <span className="text-[11px] text-slate-500">Foto inicial</span>
        </div>
        <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl h-36 flex items-center justify-center">
          <span className="text-[11px] text-slate-500">Foto recente</span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        {metrics.map((m) => (
          <div key={m.label} className="text-center">
            <p className="text-[10px] text-slate-500">{m.label}</p>
            <p className="text-xs font-medium mt-0.5">{m.value}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
