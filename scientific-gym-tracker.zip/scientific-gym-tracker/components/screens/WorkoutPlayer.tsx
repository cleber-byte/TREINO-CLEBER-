"use client";

import { useState } from "react";

export default function WorkoutPlayer() {
  const [weight, setWeight] = useState(18);
  const [reps, setReps] = useState(15);
  const [rir, setRir] = useState(2);
  const [done, setDone] = useState(false);

  return (
    <div className="p-4">
      <p className="text-xs text-slate-500">Exercício 3 de 8</p>
      <h3 className="text-lg font-medium mb-0.5">Cross over</h3>
      <p className="text-xs text-slate-400 mb-3">Peitoral (região interna)</p>

      <div className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 mb-4">
        <p className="text-[11px] text-slate-500 mb-0.5">Meta</p>
        <p className="text-sm">
          3 × 15 <span className="text-slate-500">@ 2 RIR</span>
        </p>
      </div>

      <div className="flex items-center justify-center gap-4 mb-4">
        <button
          onClick={() => setWeight((w) => Math.max(0, w - 2.5))}
          className="w-9 h-9 rounded-full border border-slate-700 text-slate-300"
        >
          −
        </button>
        <span className="text-2xl font-medium">
          {weight} <span className="text-sm text-slate-500">kg</span>
        </span>
        <button
          onClick={() => setWeight((w) => w + 2.5)}
          className="w-9 h-9 rounded-full border border-slate-700 text-slate-300"
        >
          +
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2 mb-4">
        <div>
          <label className="text-[11px] text-slate-400">Reps</label>
          <input
            type="number"
            value={reps}
            onChange={(e) => setReps(Number(e.target.value))}
            className="w-full mt-1"
          />
        </div>
        <div>
          <label className="text-[11px] text-slate-400">RIR</label>
          <input
            type="number"
            value={rir}
            onChange={(e) => setRir(Number(e.target.value))}
            className="w-full mt-1"
          />
        </div>
      </div>

      <button
        onClick={() => setDone(true)}
        className="w-full bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-medium py-2.5 rounded-lg"
      >
        {done ? "Série registrada ✓" : "Concluir série"}
      </button>

      {done && (
        <p className="text-xs text-amber-400 text-center mt-3">
          Descanso: 01:12 restantes
        </p>
      )}
    </div>
  );
}
