export default function Dashboard() {
  return (
    <div className="p-4">
      <p className="text-sm text-slate-400">Olá, Ana</p>
      <h3 className="text-lg font-medium mb-3">Segunda-feira</h3>

      <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-3 mb-3">
        <p className="text-xs text-emerald-400 mb-0.5">Treino de hoje</p>
        <p className="text-sm font-medium text-emerald-300">Peito + Bíceps + Ombro</p>
        <p className="text-xs text-emerald-400/80">8 exercícios · ~50 min</p>
      </div>

      <div className="grid grid-cols-2 gap-2 mb-3">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-2.5">
          <p className="text-[11px] text-slate-500">Sequência</p>
          <p className="text-lg font-medium">6 dias</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-2.5">
          <p className="text-[11px] text-slate-500">Meta calórica</p>
          <p className="text-lg font-medium">1120/1550</p>
        </div>
      </div>

      <p className="text-xs text-slate-400 mb-2">Acesso rápido</p>
      <div className="flex gap-2">
        {[
          { label: "Refeição", icon: "🍽️" },
          { label: "Bioimp.", icon: "📋" },
          { label: "Foto corpo", icon: "📷" },
        ].map((item) => (
          <div
            key={item.label}
            className="flex-1 text-center bg-slate-900 border border-slate-800 rounded-lg py-2.5"
          >
            <span className="text-lg">{item.icon}</span>
            <p className="text-[10px] mt-1 text-slate-400">{item.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
