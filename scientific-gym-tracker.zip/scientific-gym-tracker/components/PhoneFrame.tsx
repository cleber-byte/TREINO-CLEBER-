export default function PhoneFrame({ children }: { children: React.ReactNode }) {
  return (
    <div className="bg-slate-900 rounded-[28px] p-5 flex justify-center">
      <div className="w-[300px] bg-slate-950 rounded-3xl border border-slate-800 overflow-hidden min-h-[560px]">
        {children}
      </div>
    </div>
  );
}
