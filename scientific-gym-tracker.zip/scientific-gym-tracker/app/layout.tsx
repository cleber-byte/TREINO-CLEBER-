import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Scientific Gym Tracker",
  description: "Protótipo de experiência do cliente — treino personalizado por dados reais",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR">
      <body className="bg-slate-950 text-slate-100 min-h-screen font-sans">
        {children}
      </body>
    </html>
  );
}
