"use client";

import { useState } from "react";
import PhoneFrame from "@/components/PhoneFrame";
import Onboarding from "@/components/screens/Onboarding";
import Dashboard from "@/components/screens/Dashboard";
import WorkoutPlayer from "@/components/screens/WorkoutPlayer";
import Bioimpedance from "@/components/screens/Bioimpedance";
import Progress from "@/components/screens/Progress";

const tabs = [
  { id: "onboarding", label: "1. Onboarding", component: Onboarding },
  { id: "dashboard", label: "2. Dashboard", component: Dashboard },
  { id: "workout", label: "3. Treino ao vivo", component: WorkoutPlayer },
  { id: "bioimpedance", label: "4. Bioimpedância", component: Bioimpedance },
  { id: "progress", label: "5. Progresso", component: Progress },
];

export default function Home() {
  const [active, setActive] = useState(tabs[0].id);
  const ActiveComponent = tabs.find((t) => t.id === active)!.component;

  return (
    <main className="max-w-3xl mx-auto p-6">
      <h1 className="text-xl font-semibold text-emerald-400 mb-1">
        Scientific Gym Tracker
      </h1>
      <p className="text-sm text-slate-400 mb-6">
        Protótipo navegável — experiência do cliente
      </p>

      <div className="flex gap-2 flex-wrap mb-6">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActive(tab.id)}
            className={`text-xs px-3 py-1.5 rounded-lg border ${
              active === tab.id
                ? "bg-emerald-600 border-emerald-600 text-white"
                : "border-slate-800 text-slate-400"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <PhoneFrame>
        <ActiveComponent />
      </PhoneFrame>
    </main>
  );
}
